/**
 * Daily Horoscope App
 * Main application JavaScript file
 * Supports multiple languages: English, Hindi, Bengali
 */

document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const horoscopeForm = document.getElementById('horoscopeForm');
    const zodiacSelect = document.getElementById('zodiacSelect');
    const horoscopeResult = document.getElementById('horoscopeResult');
    const zodiacIcon = document.getElementById('zodiacIcon');
    const zodiacTitle = document.getElementById('zodiacTitle');
    const currentDateElement = document.getElementById('currentDate');
    const horoscopeText = document.getElementById('horoscopeText');
    const languageButtons = document.querySelectorAll('.language-btn');
    
    // UI elements that need translation
    const appTitle = document.getElementById('appTitle');
    const appSubtitle = document.getElementById('appSubtitle');
    const selectLabel = document.getElementById('selectLabel');
    const selectPlaceholder = document.getElementById('selectPlaceholder');
    const submitButton = document.getElementById('submitButton');
    const copyright = document.getElementById('copyright');

    // Current language (default is English)
    let currentLanguage = localStorage.getItem('selectedLanguage') || 'english';

    // Zodiac sign icons (same for all languages)
    const zodiacIcons = {
        'aries': '♈',
        'taurus': '♉',
        'gemini': '♊',
        'cancer': '♋',
        'leo': '♌',
        'virgo': '♍',
        'libra': '♎',
        'scorpio': '♏',
        'sagittarius': '♐',
        'capricorn': '♑',
        'aquarius': '♒',
        'pisces': '♓'
    };

    /**
     * Populate the zodiac sign dropdown based on current language
     */
    function populateZodiacSigns() {
        // Clear existing options except the placeholder
        while (zodiacSelect.options.length > 1) {
            zodiacSelect.remove(1);
        }
        
        // Get the translations for the current language
        const signTranslations = zodiacTranslations[currentLanguage];
        
        // Add options for each zodiac sign
        Object.keys(signTranslations).forEach(sign => {
            const option = document.createElement('option');
            option.value = sign;
            option.innerHTML = `${zodiacIcons[sign]} ${signTranslations[sign]}`;
            zodiacSelect.appendChild(option);
        });
    }

    /**
     * Update all UI text elements based on the selected language
     */
    function updateUILanguage() {
        const langData = translations[currentLanguage];
        
        // Update main UI elements
        appTitle.innerHTML = `<i class="fa-solid fa-moon"></i> ${langData.title}`;
        appSubtitle.textContent = langData.subtitle;
        selectLabel.textContent = langData.selectLabel;
        selectPlaceholder.textContent = langData.selectPlaceholder;
        submitButton.innerHTML = `<i class="fa-solid fa-stars me-2"></i> ${langData.buttonText}`;
        copyright.innerHTML = `<i class="fa-regular fa-copyright"></i> ${langData.copyright}`;
        
        // Update active language button
        languageButtons.forEach(btn => {
            if (btn.dataset.lang === currentLanguage) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
        
        // Populate the zodiac signs dropdown
        populateZodiacSigns();
        
        // If there's a previously selected sign, try to set it again
        const lastSign = localStorage.getItem('lastZodiacSign');
        if (lastSign) {
            zodiacSelect.value = lastSign;
        }
        
        // If a horoscope was already displayed, update it
        if (!horoscopeResult.classList.contains('d-none')) {
            displayHoroscope(zodiacSelect.value);
        }
    }

    /**
     * Get the horoscope message for a specific sign based on the current date
     * @param {string} sign - The zodiac sign
     * @returns {string} - The horoscope message
     */
    function getHoroscopeForToday(sign) {
        // Get current date information
        const today = new Date();
        const dayOfMonth = today.getDate();
        
        // Ensure the sign exists in our data
        if (!horoscopeData[currentLanguage] || !horoscopeData[currentLanguage][sign]) {
            // Fallback message in the current language
            if (currentLanguage === 'hindi') {
                return "क्षमा करें, हम इस राशि के लिए राशिफल नहीं ढूंढ सके। कृपया पुनः प्रयास करें।";
            } else if (currentLanguage === 'bengali') {
                return "দুঃখিত, আমরা এই রাশির জন্য কোনো রাশিফল খুঁজে পাইনি। অনুগ্রহ করে আবার চেষ্টা করুন।";
            } else {
                return "Sorry, we couldn't find a horoscope for that sign. Please try again.";
            }
        }
        
        // Get the array of possible horoscopes for this sign
        const possibleHoroscopes = horoscopeData[currentLanguage][sign];
        
        // Use the day of month to select a horoscope (will rotate through the month)
        // If we have less horoscopes than days in a month, it will wrap around
        const index = (dayOfMonth - 1) % possibleHoroscopes.length;
        
        return possibleHoroscopes[index];
    }

    /**
     * Format the current date for display in the current language
     * @returns {string} - Formatted date string
     */
    function getFormattedDate() {
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        };
        
        // Define locale mapping
        const localeMap = {
            'english': 'en-US',
            'hindi': 'hi-IN',
            'bengali': 'bn-BD'
        };
        
        return new Date().toLocaleDateString(localeMap[currentLanguage] || undefined, options);
    }

    /**
     * Display the horoscope for the selected sign
     * @param {string} sign - The zodiac sign
     */
    function displayHoroscope(sign) {
        // Set the icon 
        zodiacIcon.textContent = zodiacIcons[sign];
        
        // Set the title using the current language translation
        zodiacTitle.textContent = zodiacTranslations[currentLanguage][sign]; // Full sign name
        
        // Set the current date in the appropriate language
        currentDateElement.textContent = getFormattedDate();
        
        // Get and set the horoscope text in the current language
        const horoscopeMessage = getHoroscopeForToday(sign);
        horoscopeText.textContent = horoscopeMessage;
        
        // Show the result card with animation
        horoscopeResult.classList.remove('d-none');
        // We need to force a reflow before adding the 'show' class for the animation to work
        void horoscopeResult.offsetWidth;
        horoscopeResult.classList.add('show');
        
        // Scroll to the result card
        horoscopeResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    /**
     * Handle form submission
     * @param {Event} e - The submit event
     */
    function handleFormSubmit(e) {
        e.preventDefault();
        
        // Get the selected sign
        const selectedSign = zodiacSelect.value;
        
        // If no sign is selected, alert the user in the appropriate language
        if (!selectedSign) {
            if (currentLanguage === 'hindi') {
                alert('कृपया अपनी राशि चुनें');
            } else if (currentLanguage === 'bengali') {
                alert('অনুগ্রহ করে আপনার রাশি নির্বাচন করুন');
            } else {
                alert('Please select your zodiac sign');
            }
            return;
        }
        
        // Save the selected sign
        localStorage.setItem('lastZodiacSign', selectedSign);
        
        // Display the horoscope
        displayHoroscope(selectedSign);
    }

    /**
     * Handle language change
     * @param {Event} e - The click event
     */
    function handleLanguageChange(e) {
        const selectedLang = e.target.dataset.lang;
        if (selectedLang && selectedLang !== currentLanguage) {
            currentLanguage = selectedLang;
            localStorage.setItem('selectedLanguage', currentLanguage);
            updateUILanguage();
        }
    }

    // Event listeners
    horoscopeForm.addEventListener('submit', handleFormSubmit);
    
    // Language selector event listeners
    languageButtons.forEach(btn => {
        btn.addEventListener('click', handleLanguageChange);
    });

    // Mobile-specific adjustments
    function adjustForMobile() {
        // Check if we're on a mobile device (rough check for simplicity)
        const isMobile = window.innerWidth < 768;
        
        if (isMobile) {
            // Adjust any elements specifically for mobile if needed
            document.body.classList.add('mobile-view');
        } else {
            document.body.classList.remove('mobile-view');
        }
    }

    // Initialize the UI with the correct language
    updateUILanguage();
    
    // Run mobile adjustments on load and resize
    adjustForMobile();
    window.addEventListener('resize', adjustForMobile);
});

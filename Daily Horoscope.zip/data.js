/**
 * Data file containing horoscope messages for each zodiac sign
 * Messages rotate based on the day of the month
 * Supports multiple languages (English, Hindi, Bengali)
 */

// Translation data for UI elements
const translations = {
    english: {
        title: "Daily Horoscope",
        subtitle: "Discover what the stars have in store for you today",
        selectLabel: "Select Your Zodiac Sign",
        selectPlaceholder: "Choose your sign...",
        buttonText: "Get Horoscope",
        copyright: "© 2025 Daily Horoscope App",
        languageSelector: "Language"
    },
    hindi: {
        title: "दैनिक राशिफल",
        subtitle: "जानिए आज तारे आपके लिए क्या संदेश लेकर आए हैं",
        selectLabel: "अपनी राशि चुनें",
        selectPlaceholder: "अपनी राशि चुनें...",
        buttonText: "राशिफल देखें",
        copyright: "© 2025 दैनिक राशिफल ऐप",
        languageSelector: "भाषा"
    },
    bengali: {
        title: "দৈনিক রাশিফল",
        subtitle: "আজ তারাগুলি আপনার জন্য কী সংরক্ষণ করেছে তা আবিষ্কার করুন",
        selectLabel: "আপনার রাশি নির্বাচন করুন",
        selectPlaceholder: "আপনার রাশি বেছে নিন...",
        buttonText: "রাশিফল দেখুন",
        copyright: "© 2025 দৈনিক রাশিফল অ্যাপ",
        languageSelector: "ভাষা"
    }
};

// Zodiac signs translations
const zodiacTranslations = {
    english: {
        aries: "Aries",
        taurus: "Taurus",
        gemini: "Gemini",
        cancer: "Cancer",
        leo: "Leo",
        virgo: "Virgo",
        libra: "Libra",
        scorpio: "Scorpio",
        sagittarius: "Sagittarius",
        capricorn: "Capricorn",
        aquarius: "Aquarius",
        pisces: "Pisces"
    },
    hindi: {
        aries: "मेष",
        taurus: "वृषभ",
        gemini: "मिथुन",
        cancer: "कर्क",
        leo: "सिंह",
        virgo: "कन्या",
        libra: "तुला",
        scorpio: "वृश्चिक",
        sagittarius: "धनु",
        capricorn: "मकर",
        aquarius: "कुंभ",
        pisces: "मीन"
    },
    bengali: {
        aries: "মেষ",
        taurus: "বৃষ",
        gemini: "মিথুন",
        cancer: "কর্কট",
        leo: "সিংহ",
        virgo: "কন্যা",
        libra: "তুলা",
        scorpio: "বৃশ্চিক",
        sagittarius: "ধনু",
        capricorn: "মকর",
        aquarius: "কুম্ভ",
        pisces: "মীন"
    }
};

// Define multiple horoscope messages for each sign in different languages
const horoscopeData = {
    english: {
        aries: [
            "Today is ideal for taking initiative and starting new projects. Your energy is high, and your determination will help you overcome obstacles.",
            "Focus on personal goals today. Your competitive spirit will drive you to success, but remember to be patient with others who may not match your pace.",
            "Your natural leadership qualities shine today. Use this energy to inspire others and move forward with confidence on your path.",
            "Communication flows easily today. Express your ideas boldly, but be mindful not to come across as too forceful with your opinions.",
            "A day for physical activity and channeling your abundant energy. Exercise or outdoor activities will help you maintain balance."
        ],
        taurus: [
            "Stability and security are highlighted today. Focus on building solid foundations in your work and relationships.",
            "Your practical approach to problems impresses others. Trust your methodical nature to find solutions others might miss.",
            "Financial matters look favorable. Your natural talent for managing resources brings positive results today.",
            "Take time to appreciate beauty around you. Your sensual nature is heightened, making this perfect for enjoying art, music, or nature.",
            "Persistence pays off today. A project or relationship that seemed stalled begins to show progress thanks to your dedication."
        ],
        gemini: [
            "Your communication skills shine brightly today. Express your ideas freely, as others are particularly receptive to your perspective.",
            "Curiosity leads you to valuable discoveries. Follow your intellectual interests, as they may lead to unexpected opportunities.",
            "Connecting with others brings joy today. Your natural charm and wit make you the center of attention in social settings.",
            "Focus on versatility rather than trying to specialize today. Your ability to adapt to changing circumstances serves you well.",
            "Your quick thinking helps solve a puzzling situation. Trust your mental agility to find creative solutions others might miss."
        ],
        cancer: [
            "Emotional insights guide you wisely today. Trust your intuition, especially regarding family matters or home situations.",
            "Nurturing others brings you fulfillment today. Your natural caregiving abilities make a significant difference to those around you.",
            "Focus on creating security and comfort in your environment. Small improvements to your home enhance your sense of well-being.",
            "Your sensitivity allows you to perceive what others need before they express it. This empathic quality strengthens relationships today.",
            "Family connections bring joy and support. Reaching out to loved ones, even briefly, reinforces important bonds."
        ],
        leo: [
            "Your confidence shines today. You see opportunities where you can showcase your talents and be in the spotlight.",
            "Your creativity and passion take a project to new heights today. Listen to your heart and go in the direction that inspires you.",
            "Leadership opportunities come your way. You naturally take charge and inspire others.",
            "Your vibrant personality truly shines today. In social gatherings, you'll be the center of attention, so show your best qualities.",
            "Focus on self-expression today. Whether through art, performance, or simply sharing your ideas, your creative energy helps you feel fulfilled."
        ],
        virgo: [
            "Your analytical mind helps solve complex problems today. You can see details that others miss.",
            "Soften your perfectionism a bit. Having slightly lower expectations of yourself will bring more satisfaction and less stress.",
            "Your practicality and efficiency will be important today. Your skilled planning and organization will help resolve others' problems.",
            "Focus on health and wellness. Balance between your physical energy and mental clarity is crucial for your overall well-being.",
            "Find work-life balance. Avoid overworking and give yourself time to relax and enjoy your hobbies."
        ],
        libra: [
            "Relationships are emphasized today. You are naturally good at creating harmony and balance with others.",
            "Take advantage of your aesthetic sense. Whether decorating your home, styling your outfit, or enjoying art, your appreciation for beauty is enhanced.",
            "Don't overthink decision-making. Sometimes you stress yourself by considering too many options. Trust your intuition.",
            "Seek peace and harmony. Avoid stressful situations and spend your time with people and places that make you feel happy.",
            "Your social charm is especially strong today. Use your conversation skills to form new connections and strengthen existing ones."
        ],
        scorpio: [
            "Trust your intense emotions and intuition today. You can see beneath the surface to matters others might miss.",
            "Don't fear transformation. You have an amazing capacity for change and rebirth, and this helps you recover from difficult situations.",
            "Channel your deep energy into creative projects or important research. Your focus and determination can bring great success.",
            "Honesty in relationships is important. Go beyond superficial conversation and take time for meaningful dialogue.",
            "Your self-discipline and willpower are especially strong today. Use it to break a bad habit or tackle a new challenge."
        ],
        sagittarius: [
            "Enjoy your freedom and sense of adventure today. Follow your natural inclination to explore new experiences and ideas.",
            "Share your broad perspective and optimism with others. Your enthusiasm is contagious and can inspire people around you.",
            "Look for opportunities to travel or learn. Expanding your horizons will be especially beneficial today.",
            "Consider potential consequences before committing too quickly. Your freedom is important, so make sure whatever you do doesn't make you feel trapped.",
            "Your humor and cheerful disposition are invaluable today. In a difficult situation, your light approach can reduce tension and help find solutions."
        ],
        capricorn: [
            "Focus on your goals today. Your hard work and determination drive you toward success, especially in your career.",
            "Accept responsibilities, but don't put too much pressure on yourself. You often expect too much from yourself, so set realistic goals.",
            "Take time to reward yourself. You work so hard that sometimes you forget to rest and celebrate your achievements.",
            "Use your practical approach to financial matters. You're naturally good at managing resources, and today is a good day for long-term investments.",
            "Remember the importance of family and traditions. Keeping yourself connected to your roots can provide strength and stability."
        ],
        aquarius: [
            "Express your original ideas today. Your innovative thinking and concepts can inspire and influence others.",
            "Follow your commitment to humanitarian goals. You're naturally motivated to make changes and improve the world.",
            "Protect your personal freedom, but also understand the importance of working within your community or team. You can be equally influential alone and as part of a group.",
            "Experiment with new technologies or ideas. You're naturally good at innovation, and today your creative experiments might yield surprising results.",
            "Trust your intuition, especially about people and situations. You're often sensitive to the collective consciousness and can understand future trends."
        ],
        pisces: [
            "Recognize your imagination and empathy as your strengths. Your emotional intelligence and creative abilities are your greatest assets.",
            "Follow your dreams and fantasies, but also look for ways to connect them to reality. Find ways to express your spiritual tendencies in the practical world.",
            "It's time to forgive yourself and others. You have a deep capacity for empathy and compassion, and this can help heal you and those around you.",
            "Express yourself through music, art, or nature. These mediums can help you articulate your subtle feelings and thoughts.",
            "Understand your boundaries and learn to say 'no' when you feel tired or overwhelmed. Taking care of your emotional well-being is important."
        ]
    },
    hindi: {
        aries: [
            "आज नई परियोजनाओं की शुरुआत के लिए आदर्श दिन है। आपकी ऊर्जा उच्च है, और आपका दृढ़ संकल्प आपको बाधाओं को पार करने में मदद करेगा।",
            "आज व्यक्तिगत लक्ष्यों पर ध्यान दें। आपकी प्रतिस्पर्धी भावना आपको सफलता की ओर ले जाएगी, लेकिन दूसरों के साथ धैर्य रखें जो आपकी गति से मेल नहीं खा सकते।",
            "आज आपके प्राकृतिक नेतृत्व गुण चमकते हैं। इस ऊर्जा का उपयोग दूसरों को प्रेरित करने और अपने मार्ग पर आत्मविश्वास के साथ आगे बढ़ने के लिए करें।",
            "आज संचार आसानी से होता है। अपने विचारों को स्पष्ट रूप से व्यक्त करें, लेकिन ध्यान रखें कि आपकी राय बहुत ज़ोरदार न लगे।",
            "शारीरिक गतिविधि और अपनी प्रचुर ऊर्जा को चैनल करने का दिन है। व्यायाम या बाहरी गतिविधियां आपको संतुलन बनाए रखने में मदद करेंगी।"
        ],
        taurus: [
            "आज स्थिरता और सुरक्षा पर प्रकाश डाला गया है। अपने काम और रिश्तों में ठोस नींव बनाने पर ध्यान दें।",
            "समस्याओं के प्रति आपका व्यावहारिक दृष्टिकोण दूसरों को प्रभावित करता है। अपनी व्यवस्थित प्रकृति पर भरोसा करें ताकि ऐसे समाधान मिल सकें जिन्हें दूसरे लोग नज़रअंदाज़ कर सकते हैं।",
            "वित्तीय मामले अनुकूल दिखते हैं। संसाधनों के प्रबंधन में आपकी प्राकृतिक प्रतिभा आज सकारात्मक परिणाम लाती है।",
            "अपने आसपास की सुंदरता की सराहना करने के लिए समय निकालें। आपकी सुखद प्रकृति बढ़ जाती है, जिससे यह कला, संगीत या प्रकृति का आनंद लेने के लिए परफेक्ट बन जाता है।",
            "आज दृढ़ता का लाभ मिलता है। एक परियोजना या रिश्ता जो रुका हुआ लग रहा था, आपकी समर्पण के कारण प्रगति दिखाना शुरू कर देता है।"
        ],
        gemini: [
            "आज आपके संचार कौशल उज्ज्वल रूप से चमकते हैं। अपने विचारों को स्वतंत्र रूप से व्यक्त करें, क्योंकि दूसरे लोग विशेष रूप से आपके दृष्टिकोण के प्रति ग्रहणशील हैं।",
            "जिज्ञासा आपको मूल्यवान खोजों की ओर ले जाती है। अपनी बौद्धिक रुचियों का अनुसरण करें, क्योंकि वे अप्रत्याशित अवसरों की ओर ले जा सकती हैं।",
            "दूसरों से जुड़ना आज आनंद लाता है। आपका स्वाभाविक आकर्षण और बुद्धिमत्ता आपको सामाजिक सेटिंग में ध्यान का केंद्र बनाती है।",
            "आज विशेषज्ञता की कोशिश करने के बजाय बहुमुखी प्रतिभा पर ध्यान दें। बदलती परिस्थितियों के अनुकूल होने की आपकी क्षमता आपके लिए अच्छी रहेगी।",
            "आपकी त्वरित सोच एक पहेली भरी स्थिति को सुलझाने में मदद करती है। रचनात्मक समाधान खोजने के लिए अपनी मानसिक चपलता पर भरोसा करें जिन्हें दूसरे लोग मिस कर सकते हैं।"
        ],
        cancer: [
            "भावनात्मक अंतर्दृष्टि आज आपका मार्गदर्शन करती है। अपनी अंतर्ज्ञान पर भरोसा करें, विशेष रूप से परिवार के मामलों या घर की स्थितियों के बारे में।",
            "दूसरों की देखभाल करना आज आपको संतुष्टि देता है। आपकी स्वाभाविक देखभाल करने की क्षमताएं आपके आसपास के लोगों के लिए एक महत्वपूर्ण अंतर बनाती हैं।",
            "अपने वातावरण में सुरक्षा और आराम बनाने पर ध्यान दें। आपके घर में छोटे सुधार आपकी खुशहाली की भावना को बढ़ाते हैं।",
            "आपकी संवेदनशीलता आपको यह समझने की अनुमति देती है कि दूसरों को क्या चाहिए इससे पहले कि वे इसे व्यक्त करें। आज यह समझदार गुण रिश्तों को मजबूत करता है।",
            "परिवार के संबंध आनंद और समर्थन लाते हैं। प्रियजनों से, यहां तक कि संक्षेप में भी, संपर्क करना महत्वपूर्ण बंधनों को मजबूत करता है।"
        ],
        leo: [
            "आज आपका आत्मविश्वास चमकता है। आप ऐसे अवसरों को देखते हैं जहां आप अपनी प्रतिभा दिखा सकते हैं और केंद्र-बिंदु बन सकते हैं।",
            "आपकी रचनात्मकता और जुनून आज किसी प्रोजेक्ट को नई ऊंचाइयों पर ले जाते हैं। अपने दिल की आवाज़ सुनें और उस दिशा में जाएं जो आपको प्रेरित करती है।",
            "नेतृत्व के अवसर आपके सामने आते हैं। आप स्वाभाविक रूप से अगुवाई करते हैं और दूसरों को प्रेरित करते हैं।",
            "आपका चमकदार व्यक्तित्व आज वास्तव में चमकता है। सामाजिक समारोहों में आप ध्यान का केंद्र होंगे, इसलिए अपने सर्वश्रेष्ठ पहलुओं को दिखाएं।",
            "आज आत्म-अभिव्यक्ति पर ध्यान दें। चाहे कला, मंच, या सिर्फ़ अपने विचारों को साझा करना हो, आपकी रचनात्मक ऊर्जा परिपूर्ण महसूस करने में आपकी मदद करेगी।"
        ],
        virgo: [
            "आपका विश्लेषणात्मक दिमाग आज जटिल समस्याओं को हल करने में सहायता करता है। आप विवरणों को देख सकते हैं जो दूसरों से छूट जाते हैं।",
            "पूर्णतावाद को थोड़ा नरम करें। अपने आप से कुछ कम अपेक्षाएं रखने से आपको अधिक संतोष मिलेगा और कम तनाव होगा।",
            "आपकी व्यावहारिकता और कुशलता आज महत्वपूर्ण होगी। आपकी कुशल योजना और संगठन दूसरों की समस्याओं को सुलझाने में मदद करेगी।",
            "स्वास्थ्य और कल्याण पर ध्यान दें। आपकी शारीरिक ऊर्जा और मानसिक स्पष्टता के बीच संतुलन आपके समग्र स्वास्थ्य के लिए महत्वपूर्ण है।",
            "कार्य-जीवन संतुलन खोजें। बहुत अधिक काम करने से बचें और अपने आप को आराम करने और अपने शौक का आनंद लेने के लिए समय दें।"
        ],
        libra: [
            "आज संबंधों पर जोर दिया गया है। आप दूसरों के साथ सद्भाव और संतुलन बनाने में प्राकृतिक रूप से अच्छे हैं।",
            "अपनी सौंदर्य बोध का लाभ उठाएं। चाहे अपने घर को सजाने, अपने पहनावे को स्टाइल करने या कला का आनंद लेने के लिए, आपकी सुंदरता की समझ बढ़ी हुई है।",
            "निर्णय लेने के बारे में ज्यादा सोच-विचार न करें। कभी-कभी आप बहुत अधिक विकल्पों पर विचार करके स्वयं को परेशान कर लेते हैं। अपने अंतर्ज्ञान पर भरोसा करें।",
            "शांति और सामंजस्य की तलाश करें। तनावपूर्ण परिस्थितियों से बचें और ऐसे लोगों और स्थानों के साथ अपना समय बिताएं जो आपको प्रसन्न महसूस कराते हैं।",
            "आज आपका सामाजिक आकर्षण विशेष रूप से मजबूत है। अपनी बातचीत के कौशल का उपयोग नए संबंध बनाने और मौजूदा को मजबूत करने के लिए करें।"
        ],
        scorpio: [
            "आज आपकी गहन भावनाओं और अंतर्ज्ञान पर भरोसा करें। आप सतह के नीचे छिपे मामलों को देख सकते हैं जिन्हें दूसरे लोग याद कर सकते हैं।",
            "परिवर्तन से न डरें। आप में बदलाव और पुनर्जन्म की अद्भुत क्षमता है, और यह आपको मुश्किल परिस्थितियों से उबरने में मदद करती है।",
            "अपनी गहन ऊर्जा को रचनात्मक परियोजनाओं या महत्वपूर्ण अनुसंधान में लगाएं। आपका फोकस और दृढ़ संकल्प आपको बड़ी सफलता दिला सकता है।",
            "रिश्तों में ईमानदारी महत्वपूर्ण है। सतही बातचीत से परे जाएं और अर्थपूर्ण संवाद के लिए समय निकालें।",
            "आपकी आत्म-अनुशासन और इच्छाशक्ति आज विशेष रूप से मजबूत है। इसका उपयोग अपनी बुरी आदतों को छोड़ने या एक नई चुनौती का सामना करने के लिए करें।"
        ],
        sagittarius: [
            "आज अपनी स्वतंत्रता और साहसिक स्पर्श का आनंद लें। नए अनुभवों और विचारों की खोज के लिए अपनी स्वाभाविक प्रवृत्ति का पालन करें।",
            "अपने विस्तृत दृष्टिकोण और आशावाद को दूसरों के साथ साझा करें। आपका उत्साह संक्रामक है और वह आपके आसपास के लोगों को प्रेरित कर सकता है।",
            "यात्रा या शिक्षा के अवसरों की तलाश करें। आपके क्षितिज का विस्तार करना आज विशेष रूप से फायदेमंद होगा।",
            "प्रतिबद्धताओं पर बहुत जल्दी हस्ताक्षर करने से पहले संभावित परिणामों पर विचार करें। आपकी स्वतंत्रता महत्वपूर्ण है, इसलिए सुनिश्चित करें कि आप जो भी करते हैं वह आपको बंधा हुआ महसूस न कराए।",
            "आपका हास्य और प्रसन्न स्वभाव आज अमूल्य है। एक कठिन स्थिति में, आपका हल्का दृष्टिकोण तनाव को कम कर सकता है और समाधान खोजने में मदद कर सकता है।"
        ],
        capricorn: [
            "आज अपने लक्ष्यों पर ध्यान केंद्रित करें। आपकी कड़ी मेहनत और दृढ़ संकल्प आपको सफलता की ओर ले जाता है, खासकर करियर में।",
            "जिम्मेदारियों को स्वीकार करें, लेकिन अपने आप पर बहुत अधिक दबाव न डालें। आप अक्सर खुद से बहुत अधिक अपेक्षा करते हैं, इसलिए यथार्थवादी लक्ष्य निर्धारित करें।",
            "अपने आप को पुरस्कृत करने के लिए समय निकालें। आप इतनी मेहनत करते हैं कि कभी-कभी आप विश्राम करना और अपनी उपलब्धियों का जश्न मनाना भूल जाते हैं।",
            "वित्तीय मामलों के प्रति अपने व्यावहारिक दृष्टिकोण का उपयोग करें। आप संसाधनों के प्रबंधन में प्राकृतिक रूप से अच्छे हैं, और आज दीर्घकालिक निवेशों के लिए एक अच्छा दिन है।",
            "परिवार और परंपराओं के महत्व को याद रखें। अपने आपको अपनी जड़ों से जोड़े रखना आपको ताकत और स्थिरता प्रदान कर सकता है।"
        ],
        aquarius: [
            "आज अपने मौलिक विचारों को व्यक्त करें। आपकी नवीन सोच और अवधारणाएं दूसरों को प्रेरित और प्रभावित कर सकती हैं।",
            "मानवतावादी लक्ष्यों के लिए अपनी प्रतिबद्धता का पालन करें। आप बदलाव लाने और दुनिया को बेहतर बनाने के लिए स्वाभाविक रूप से प्रेरित हैं।",
            "अपने व्यक्तिगत स्वतंत्रता की रक्षा करें, लेकिन साथ ही साथ अपने समुदाय या टीम के भीतर काम करने के महत्व को समझें। आप अकेले और एक समूह के हिस्से के रूप में भी समान रूप से प्रभावशाली हो सकते हैं।",
            "नई तकनीकों या विचारों के साथ प्रयोग करें। आप नवाचार में प्राकृतिक रूप से अच्छे हैं, और आज आपके रचनात्मक प्रयोगों से आश्चर्यजनक परिणाम मिल सकते हैं।",
            "अपनी अंतर्ज्ञान पर भरोसा करें, खासकर लोगों और स्थितियों के बारे में। आप अक्सर सामूहिक चेतना के प्रति संवेदनशील होते हैं और भविष्य की प्रवृत्तियों को समझ सकते हैं।"
        ],
        pisces: [
            "अपनी कल्पनाशीलता और सहानुभूति को अपनी ताकत के रूप में पहचानें। आपकी भावनात्मक बुद्धिमत्ता और रचनात्मक क्षमताएं आपके सबसे बड़े संपत्ति हैं।",
            "अपने सपनों और कल्पनाओं का पालन करें, लेकिन उन्हें वास्तविकता से जोड़ने के तरीके भी खोजें। आपकी आध्यात्मिक प्रवृत्तियों को व्यावहारिक दुनिया में अभिव्यक्त करने के तरीके खोजें।",
            "अपने आप को और दूसरों को माफ करने का समय है। आपके पास सहानुभूति और करुणा की गहरी क्षमता है, और यह आपको और आपके आसपास के लोगों को चंगा करने में मदद कर सकती है।",
            "संगीत, कला, या प्रकृति के माध्यम से अपने आप को अभिव्यक्त करें। ये माध्यम आपके सूक्ष्म भावनाओं और विचारों को व्यक्त करने में सहायता कर सकते हैं।",
            "अपनी सीमाओं को समझें और जब आप थके हुए या अभिभूत महसूस करें तो 'नहीं' कहना सीखें। अपने भावनात्मक कल्याण की देखभाल करना महत्वपूर्ण है।"
        ]
    },
    bengali: {
        aries: [
            "আজ নতুন প্রকল্প শুরু করার জন্য আদর্শ। আপনার শক্তি বেশি এবং আপনার দৃঢ়তা আপনাকে বাধা অতিক্রম করতে সাহায্য করবে।",
            "আজ ব্যক্তিগত লক্ষ্যগুলির উপর ফোকাস করুন। আপনার প্রতিযোগিতামূলক মনোভাব আপনাকে সাফল্যের দিকে নিয়ে যাবে, তবে যারা আপনার গতির সাথে মিলতে নাও পারে তাদের সাথে ধৈর্য রাখতে মনে রাখবেন।",
            "আজ আপনার স্বাভাবিক নেতৃত্বের গুণাবলী উজ্জ্বল। এই শক্তি ব্যবহার করুন অন্যদের অনুপ্রাণিত করতে এবং আত্মবিশ্বাসের সাথে আপনার পথে এগিয়ে যেতে।",
            "আজ যোগাযোগ সহজেই প্রবাহিত হয়। আপনার ধারণাগুলি সাহসের সাথে প্রকাশ করুন, তবে আপনার মতামত যাতে খুব জোরালো না হয় সেদিকে সতর্ক থাকুন।",
            "শারীরিক কার্যকলাপ এবং আপনার প্রচুর শক্তি চ্যানেল করার দিন। ব্যায়াম বা বাইরের কার্যকলাপ আপনাকে ভারসাম্য বজায় রাখতে সাহায্য করবে।"
        ],
        taurus: [
            "আজ স্থিতিশীলতা এবং নিরাপত্তা হাইলাইট করা হয়েছে। আপনার কাজ এবং সম্পর্কগুলিতে শক্ত ভিত্তি তৈরি করার উপর ফোকাস করুন।",
            "সমস্যাগুলির প্রতি আপনার ব্যবহারিক দৃষ্টিভঙ্গি অন্যদের প্রভাবিত করে। আপনার পদ্ধতিগত প্রকৃতির উপর আস্থা রাখুন এমন সমাধান খুঁজে পেতে যা অন্যরা হারিয়ে ফেলতে পারে।",
            "আর্থিক বিষয়গুলি অনুকূল দেখাচ্ছে। সম্পদ পরিচালনায় আপনার স্বাভাবিক প্রতিভা আজ ইতিবাচক ফলাফল আনে।",
            "আপনার চারপাশের সৌন্দর্য উপভোগ করার জন্য সময় নিন। আপনার ইন্দ্রিয়গত প্রকৃতি বাড়ানো হয়, যা শিল্প, সঙ্গীত, বা প্রকৃতি উপভোগ করার জন্য নিখুঁত করে তোলে।",
            "অধ্যবসায় আজ ফল দেয়। একটি প্রকল্প বা সম্পর্ক যা স্থবির মনে হচ্ছিল তা আপনার উৎসর্গের কারণে অগ্রগতি দেখাতে শুরু করে।"
        ],
        gemini: [
            "আজ আপনার যোগাযোগ দক্ষতা উজ্জ্বলভাবে উজ্জ্বল। আপনার ধারণাগুলি স্বাধীনভাবে প্রকাশ করুন, কারণ অন্যরা বিশেষভাবে আপনার দৃষ্টিকোণের প্রতি গ্রহণযোগ্য।",
            "কৌতূহল আপনাকে মূল্যবান আবিষ্কারের দিকে নিয়ে যায়। আপনার বুদ্ধিগত আগ্রহ অনুসরণ করুন, কারণ তারা অপ্রত্যাশিত সুযোগের দিকে নিয়ে যেতে পারে।",
            "অন্যদের সাথে সংযোগ করা আজ আনন্দ আনে। আপনার স্বাভাবিক আকর্ষণ এবং বুদ্ধিমত্তা আপনাকে সামাজিক পরিবেশে মনোযোগের কেন্দ্র করে তোলে।",
            "আজ বিশেষীকরণের চেষ্টা করার পরিবর্তে বহুমুখীতার উপর ফোকাস করুন। পরিবর্তনশীল পরিস্থিতির সাথে খাপ খাইয়ে নেওয়ার আপনার ক্ষমতা আপনাকে ভালো পরিবেশন করে।",
            "আপনার দ্রুত চিন্তাভাবনা একটি ধাঁধাপূর্ণ পরিস্থিতি সমাধান করতে সাহায্য করে। অন্যরা মিস করতে পারে এমন সৃজনশীল সমাধান খুঁজে পেতে আপনার মানসিক স্ফূর্তির উপর আস্থা রাখুন।"
        ],
        cancer: [
            "আবেগপূর্ণ অন্তর্দৃষ্টি আজ আপনাকে জ্ঞানী নির্দেশনা দেয়। আপনার স্বজ্ঞাত জ্ঞানের উপর আস্থা রাখুন, বিশেষ করে পারিবারিক বিষয় বা বাড়ির পরিস্থিতি সম্পর্কে।",
            "অন্যদের যত্ন নেওয়া আজ আপনাকে পূর্ণতা দেয়। আপনার স্বাভাবিক পরিচর্যাকারী ক্ষমতা আপনার চারপাশের লোকেদের জন্য একটি উল্লেখযোগ্য পার্থক্য তৈরি করে।",
            "আপনার পরিবেশে নিরাপত্তা এবং আরাম তৈরি করার উপর ফোকাস করুন। আপনার বাড়িতে ছোট উন্নতি আপনার সুস্থতার অনুভূতি বাড়ায়।",
            "আপনার সংবেদনশীলতা আপনাকে অন্যদের প্রকাশ করার আগে তাদের কী প্রয়োজন তা অনুধাবন করতে দেয়। এই সহানুভূতিশীল গুণটি আজ সম্পর্ক শক্তিশালী করে।",
            "পারিবারিক সংযোগ আনন্দ এবং সমর্থন আনে। প্রিয়জনদের সাথে যোগাযোগ করা, এমনকি সংক্ষেপে, গুরুত্বপূর্ণ বন্ধন শক্তিশালী করে।"
        ],
        leo: [
            "আজ আপনার আত্মবিশ্বাস উজ্জ্বল। আপনি এমন সুযোগ দেখেন যেখানে আপনি আপনার প্রতিভা প্রদর্শন করতে পারেন এবং কেন্দ্রবিন্দু হতে পারেন।",
            "আপনার সৃজনশীলতা এবং আবেগ আজ একটি প্রকল্পকে নতুন উচ্চতায় নিয়ে যায়। আপনার হৃদয়ের কথা শুনুন এবং সেই দিকে যান যা আপনাকে অনুপ্রাণিত করে।",
            "নেতৃত্বের সুযোগ আপনার কাছে আসে। আপনি স্বাভাবিকভাবে নেতৃত্ব দেন এবং অন্যদের অনুপ্রাণিত করেন।",
            "আপনার উজ্জ্বল ব্যক্তিত্ব আজ সত্যিই উজ্জ্বল। সামাজিক অনুষ্ঠানে আপনি মনোযোগের কেন্দ্র হবেন, তাই আপনার সেরা দিকগুলি প্রদর্শন করুন।",
            "আজ আত্ম-অভিব্যক্তির উপর ফোকাস করুন। শিল্প, মঞ্চ, বা শুধু আপনার ধারণা ভাগ করা হোক না কেন, আপনার সৃজনশীল শক্তি আপনাকে পূর্ণতা অনুভব করতে সাহায্য করবে।"
        ],
        virgo: [
            "আপনার বিশ্লেষণাত্মক মন আজ জটিল সমস্যা সমাধানে সাহায্য করে। আপনি এমন বিবরণ দেখতে পারেন যা অন্যরা মিস করে।",
            "আপনার পূর্ণতাবাদকে একটু নরম করুন। নিজের থেকে অল্প কম প্রত্যাশা রাখলে আরও বেশি সন্তুষ্টি এবং কম চাপ আসবে।",
            "আপনার ব্যবহারিকতা এবং দক্ষতা আজ গুরুত্বপূর্ণ হবে। আপনার দক্ষ পরিকল্পনা এবং সংগঠন অন্যদের সমস্যা সমাধানে সাহায্য করবে।",
            "স্বাস্থ্য এবং সুস্থতার উপর ফোকাস করুন। আপনার শারীরিক শক্তি এবং মানসিক স্বচ্ছতার মধ্যে ভারসাম্য আপনার সামগ্রিক সুস্থতার জন্য অত্যন্ত গুরুত্বপূর্ণ।",
            "কাজ-জীবন ভারসাম্য খুঁজুন। অতিরিক্ত কাজ করা এড়িয়ে চলুন এবং নিজেকে বিশ্রাম নিতে এবং আপনার শখ উপভোগ করার জন্য সময় দিন।"
        ],
        pisces: [
            "আপনার কল্পনাপ্রবণতা এবং সহানুভূতিকে আপনার শক্তি হিসাবে স্বীকৃতি দিন। আপনার আবেগময় বুদ্ধিমত্তা এবং সৃজনশীল ক্ষমতাগুলি আপনার বৃহত্তম সম্পদ।",
            "আপনার স্বপ্ন এবং কল্পনাগুলি অনুসরণ করুন, তবে সেগুলিকে বাস্তবতার সাথে সংযুক্ত করার উপায়ও খুঁজুন। আপনার আধ্যাত্মিক প্রবণতাগুলিকে ব্যবহারিক পৃথিবীতে প্রকাশ করার উপায় খুঁজুন।",
            "নিজেকে এবং অন্যদের ক্ষমা করার সময় এসেছে। আপনার সহানুভূতি এবং করুণার গভীর ক্ষমতা রয়েছে, এবং এটি আপনাকে এবং আপনার চারপাশের লোকেদের নিরাময় করতে সাহায্য করতে পারে।",
            "সঙ্গীত, শিল্প, বা প্রকৃতির মাধ্যমে নিজেকে প্রকাশ করুন। এই মাধ্যমগুলি আপনার সূক্ষ্ম অনুভূতি এবং চিন্তাভাবনা প্রকাশ করতে সাহায্য করতে পারে।",
            "আপনার সীমাবদ্ধতা বুঝুন এবং যখন আপনি ক্লান্ত বা অভিভূত বোধ করেন তখন 'না' বলতে শিখুন। আপনার আবেগময় সুস্থতার যত্ন নেওয়া গুরুত্বপূর্ণ।"
        ]
    }
};

// Export the data for use in app.js